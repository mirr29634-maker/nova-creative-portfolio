# Nova — Creative Portfolio

A responsive, stylish personal portfolio starter made with plain HTML, CSS, and JavaScript. No build tools or installation required.

## Preview locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a GitHub repository (for example, `nova-portfolio`).
2. Upload `index.html`, `style.css`, and `script.js` to the repository's root. Keep `README.md` too.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Wait a little and refresh the Pages section for the published website link.

## Make it yours
- Edit the text in `index.html` to add your name, bio, real projects, and contact email.
- Change colors near the top of `style.css` in the `:root` section.
- This is a starter template; the sample projects are concepts, not claims about completed work.
